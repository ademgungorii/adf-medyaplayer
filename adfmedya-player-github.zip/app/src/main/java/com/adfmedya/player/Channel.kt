package com.adfmedya.player
data class Channel(val name: String, val url: String)
